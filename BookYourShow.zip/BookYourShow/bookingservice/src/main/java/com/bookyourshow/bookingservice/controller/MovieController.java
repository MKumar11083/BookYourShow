package com.bookyourshow.bookingservice.controller;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bookyourshow.bookingservice.globalexception.CustomBookingException;
import com.bookyourshow.bookingservice.model.Booking;
import com.bookyourshow.bookingservice.service.BookingService;

@RestController
public class MovieController {
	
	private static final Logger logger = LoggerFactory.getLogger(MovieController.class);
	
	@Autowired
	private BookingService bookingService;
	
	@PostMapping(value = "/booking",consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Booking> saveBooking(@RequestBody Booking booking){
		try {
			Optional<Booking> optionalObject = Optional.ofNullable(booking);
			if(!optionalObject.isEmpty()) {
				booking =bookingService.saveBooking(booking);
			}
			
		} catch (Exception e) {
			String message=String.format("Error occured: %s", e.getMessage());
			logger.error(message);
			throw new CustomBookingException(message);
		}
		return new ResponseEntity<>(booking, HttpStatus.OK);
	}

}
