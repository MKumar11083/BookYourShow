package com.bookyourshow.bookingservice.globalexception;

public class CustomBookingException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String errorMessage;
	
	public CustomBookingException(String errorMessage) {
		super(errorMessage);
	}
	
	

}
