package com.bookyourshow.bookingservice.model;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.Data;

@Entity
@Data
@Table(name = "movie_bookings")
public class Booking {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "booking_id")
	private Long bookingId;
	
	@ManyToOne
	@JoinColumn(name = "user_id")
	private User user;
	
	@ManyToOne
	@JoinColumn(name = "showtime_id")
	private Showtime showtime;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "booking_date")
	private Date bookingDate;
	
	@Column(name = "total_price")
	private Double totalPrice;
	
	@Column(name = "status")
	@Enumerated(EnumType.STRING)
	private Status status;

}
