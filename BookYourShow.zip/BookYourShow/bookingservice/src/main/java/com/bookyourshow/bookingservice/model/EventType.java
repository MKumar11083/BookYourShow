package com.bookyourshow.bookingservice.model;

public enum EventType {
	
	MOVIE, SPORTSEVENT

}
