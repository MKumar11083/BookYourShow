package com.bookyourshow.bookingservice.model;

public class Movie {

}
