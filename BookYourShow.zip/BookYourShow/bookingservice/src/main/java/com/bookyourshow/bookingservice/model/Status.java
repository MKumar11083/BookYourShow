package com.bookyourshow.bookingservice.model;
public enum Status {
    PENDING,
    CONFIRMED,
    CANCELLED
}
