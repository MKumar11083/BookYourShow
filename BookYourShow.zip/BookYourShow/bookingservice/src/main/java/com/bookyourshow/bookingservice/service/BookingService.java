package com.bookyourshow.bookingservice.service;

import com.bookyourshow.bookingservice.model.Booking;

public interface BookingService {
	
	public Booking saveBooking(Booking booking);

}
