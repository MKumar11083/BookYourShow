package com.bookyourshow.bookingservice.service;

import java.time.LocalDateTime;

public interface Event {
    String getName();
    String getDescription();
    LocalDateTime getDateTime();
    double getTicketPrice();
}
