package com.bookyourshow.bookingservice.service;
import java.math.BigDecimal;

import com.bookyourshow.bookingservice.utill.PaymentDetails;
import com.bookyourshow.bookingservice.utill.PaymentMethod;
import com.bookyourshow.bookingservice.utill.PaymentResponse;
import com.bookyourshow.bookingservice.utill.RefundResponse;

public interface PaymentService {
    /**
     * Process a payment for a given amount using the specified payment method.
     *
     * @param paymentMethod The payment method used for the transaction.
     * @param amount        The payment amount.
     * @return A payment response indicating the status of the transaction.
     */
    PaymentResponse processPayment(PaymentMethod paymentMethod, BigDecimal amount);

    /**
     * Refund a payment for a given transaction ID.
     *
     * @param transactionId The ID of the original transaction to be refunded.
     * @return A refund response indicating the status of the refund operation.
     */
    RefundResponse refundPayment(String transactionId);

    /**
     * Retrieve payment details for a given transaction ID.
     *
     * @param transactionId The ID of the transaction for which payment details are requested.
     * @return Payment details for the specified transaction.
     */
    PaymentDetails getPaymentDetails(String transactionId);
}

