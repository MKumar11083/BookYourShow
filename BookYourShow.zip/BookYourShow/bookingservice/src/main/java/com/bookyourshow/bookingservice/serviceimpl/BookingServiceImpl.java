package com.bookyourshow.bookingservice.serviceimpl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookyourshow.bookingservice.model.Booking;
import com.bookyourshow.bookingservice.repository.BookingRepository;
import com.bookyourshow.bookingservice.service.BookingService;

import jakarta.transaction.Transactional;

@Service
public class BookingServiceImpl implements BookingService {

	private static final Logger logger = LoggerFactory.getLogger(BookingServiceImpl.class);

	@Autowired
	private BookingRepository bookingRepository;

	@Override
	@Transactional
	public Booking saveBooking(Booking booking) {
		try {
			booking = bookingRepository.save(booking);
		} catch (Exception e) {
			logger.error("Error occured during booking: {}", e.getMessage());
		}

		return booking;
	}

}
