package com.bookyourshow.bookingservice.serviceimpl;

import java.time.LocalDateTime;

import com.bookyourshow.bookingservice.service.Event;
import com.bookyourshow.bookingservice.service.EventFactory;

public class EventBookingService {
    private EventFactory eventFactory;

    public EventBookingService(EventFactory eventFactory) {
        this.eventFactory = eventFactory;
    }

    public Event bookEvent(String name, String description, LocalDateTime dateTime, double ticketPrice) {
        return eventFactory.createEvent(name, description, dateTime, ticketPrice);
    }
}