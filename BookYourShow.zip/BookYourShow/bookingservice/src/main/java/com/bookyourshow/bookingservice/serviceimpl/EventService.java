package com.bookyourshow.bookingservice.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookyourshow.bookingservice.model.Event;
import com.bookyourshow.bookingservice.repository.EventRepository;

@Service
public class EventService {
    private final EventRepository eventRepository;

    @Autowired
    public EventService(EventRepository eventRepository) {
        this.eventRepository = eventRepository;
    }

    public Event bookEvent(Event event) {
        // Save the event to the database
        return eventRepository.save(event);
    }

    public List<Event> getAllEvents() {
        // Retrieve all events from the database
        return eventRepository.findAll();
    }

    // Implement other methods as needed
}
