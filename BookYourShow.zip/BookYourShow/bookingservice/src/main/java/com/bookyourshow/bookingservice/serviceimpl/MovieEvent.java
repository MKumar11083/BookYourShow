package com.bookyourshow.bookingservice.serviceimpl;

import java.time.LocalDateTime;

import com.bookyourshow.bookingservice.service.Event;

public class MovieEvent implements Event {
    private String name;
    private String description;
    private LocalDateTime dateTime;
    private double ticketPrice;
    
    public MovieEvent(String name, String description, LocalDateTime dateTime, double ticketPrice) {
    	this.name= name;
    	this.description= description;
    	this.dateTime= dateTime;
    	this.ticketPrice= ticketPrice;
	}
    
	@Override
	public String getName() {
		return this.name;
	}
	@Override
	public String getDescription() {
		return this.description;
	}
	@Override
	public LocalDateTime getDateTime() {
		return this.dateTime;
	}
	@Override
	public double getTicketPrice() {
		return this.ticketPrice;
	}

}