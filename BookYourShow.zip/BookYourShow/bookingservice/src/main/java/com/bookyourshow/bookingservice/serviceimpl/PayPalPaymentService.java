/*
 * package com.bookyourshow.bookingservice.serviceimpl;
 * 
 * import java.io.IOException; import java.util.List; import
 * com.paypal.core.PayPalHttpClient; import
 * com.paypal.orders.OrdersCaptureRequest; import
 * com.paypal.orders.OrdersCreateRequest; import
 * com.paypal.orders.PurchaseUnitRequest;
 * 
 * import io.netty.handler.codec.http.HttpResponse;
 * 
 * public class PayPalPaymentService { private final PayPalHttpClient client;
 * 
 * public PayPalPaymentService() { // Replace with your PayPal API credentials
 * PayPalEnvironment environment = new PayPalEnvironment.Sandbox(
 * "YOUR_CLIENT_ID", "YOUR_CLIENT_SECRET" ); this.client = new
 * PayPalHttpClient(environment); }
 * 
 * public String createOrder(double amount, String currency) throws IOException
 * { OrdersCreateRequest request = new OrdersCreateRequest();
 * request.headers().contentType("application/json");
 * 
 * PurchaseUnitRequest purchaseUnitRequest = new PurchaseUnitRequest()
 * .amountWithBreakdown(new PurchaseUnitAmountWithBreakdown()
 * .currencyCode(currency) .value(String.format("%.2f", amount)))
 * .description("Payment for your order");
 * 
 * List<PurchaseUnitRequest> purchaseUnitRequests =
 * List.of(purchaseUnitRequest); request.purchaseUnits(purchaseUnitRequests);
 * 
 * Order order = client.execute(request).result();
 * 
 * return order.id(); }
 * 
 * public boolean capturePayment(String orderId) throws IOException {
 * OrdersCaptureRequest request = new OrdersCaptureRequest(orderId);
 * request.headers().contentType("application/json");
 * 
 * HttpResponse<Order> response = client.execute(request);
 * 
 * return "COMPLETED".equals(response.result().status()); } }
 */