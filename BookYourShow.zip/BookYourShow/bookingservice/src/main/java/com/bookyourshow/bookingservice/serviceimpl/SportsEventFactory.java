package com.bookyourshow.bookingservice.serviceimpl;

import java.time.LocalDateTime;

import com.bookyourshow.bookingservice.service.Event;
import com.bookyourshow.bookingservice.service.EventFactory;

public class SportsEventFactory implements EventFactory {
    @Override
    public Event createEvent(String name, String description, LocalDateTime dateTime, double ticketPrice) {
        return new SportsEvent(name, description, dateTime, ticketPrice);
    }
}