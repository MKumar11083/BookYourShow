package com.bookyourshow.bookingservice.utill;

import java.math.BigDecimal;

public class PaymentDetails {
    private String transactionId;
    private BigDecimal amount;
    private PaymentMethod paymentMethod;
    private PaymentStatus status;
    // Additional payment details

    // Constructors, getters, and setters
}

