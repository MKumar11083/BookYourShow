package com.bookyourshow.bookingservice.utill;
public enum PaymentMethod {
    CREDIT_CARD,
    PAYPAL,
    GOOGLE_PAY,
    APPLE_PAY,
    // Add more payment methods as needed
}

