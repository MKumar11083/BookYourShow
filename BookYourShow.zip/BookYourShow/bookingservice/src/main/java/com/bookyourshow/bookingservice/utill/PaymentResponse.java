package com.bookyourshow.bookingservice.utill;
public class PaymentResponse {
    private String transactionId;
    private PaymentStatus status;

    // Constructors, getters, and setters
}

