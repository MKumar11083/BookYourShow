package com.bookyourshow.bookingservice.utill;

import org.springframework.web.client.RestTemplate;

public class PaymentServiceUtill {
	
	private RestTemplate restTemplate;
	
	
	

}
