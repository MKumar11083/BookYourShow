package com.bookyourshow.bookingservice.utill;
public enum PaymentStatus {
    SUCCESS,
    PENDING,
    FAILED,
    // Add more payment statuses as needed
}

