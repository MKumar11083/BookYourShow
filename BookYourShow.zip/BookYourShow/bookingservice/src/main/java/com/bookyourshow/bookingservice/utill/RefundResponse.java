package com.bookyourshow.bookingservice.utill;
public class RefundResponse {
    private String refundId;
    private RefundStatus status;

    // Constructors, getters, and setters
}

