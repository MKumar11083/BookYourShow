package com.bookyourshow.bookingservice.utill;
public enum RefundStatus {
    APPROVED,
    PENDING,
    FAILED,
    // Add more refund statuses as needed
}
