package com.bookyourmovie.theatreservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TheatreserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TheatreserviceApplication.class, args);
	}

}
