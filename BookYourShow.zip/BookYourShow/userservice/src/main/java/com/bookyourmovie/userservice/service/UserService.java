package com.bookyourmovie.userservice.service;

import com.bookyourmovie.userservice.model.User;

public interface UserService {
	
	public User saveUser(User user);

}
