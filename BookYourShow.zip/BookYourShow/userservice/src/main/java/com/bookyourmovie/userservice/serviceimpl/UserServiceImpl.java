package com.bookyourmovie.userservice.serviceimpl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookyourmovie.userservice.model.User;
import com.bookyourmovie.userservice.repository.UserRepository;
import com.bookyourmovie.userservice.service.UserService;

import jakarta.transaction.Transactional;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserRepository userRepository;
	
	Logger logger=LoggerFactory.getLogger(UserServiceImpl.class);

	@Override
	@Transactional
	public User saveUser(User user) {
		try {
			userRepository.save(user);
		} catch (Exception e) {
			logger.error("Error occured during user save {}", e.getMessage());
		}
		return user;
	}

}
